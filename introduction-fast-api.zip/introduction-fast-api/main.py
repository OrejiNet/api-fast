from fastapi import FastAPI, Body
from os import environ as env
from pydantic import BaseModel, Field
from typing import Optional, List
import datetime

app = FastAPI()

app.title = "Mi primera aplicacion con FastAPI"
app.version = "2.0.0"

class Movie(BaseModel):
    id: Optional[int] = None
    title: str = Field(min_length=5, max_length=100, default='My movie')
    year: int = Field(le=datetime.date.today().year, ge =1900)
    overview: str = Field(min_length=15,max_length=50, default="This movie is about")
    rating: float = Field(ge=0, le=10, default=10)
    category: str = Field(min_length=5, max_length=20, default='Action')

movies: List[Movie] = []

@app.get('/',tags=['Home'])
def index():
    return "Hello World 1"

@app.get('/movies',tags=['Movies'])
def get_movies() -> List[Movie]:
    return [movie.model_dump() for movie in movies]

# Get movie by route params
@app.get('/movies/{id}',tags=['Movies'])
def get_movie(id:int):
    return id

# Get Data env variables
@app.get('/env/',tags=['Enviroment'])
def get_env_variable():
    return {"details": f"Hello world! secret = {env['NAME_SECRET']}"}

# Get movie by query params
@app.get('/movies/', tags=['Movies'])
def get_movie_by_category(category:str, year: int):
    return f"category: {category} year: {year}" 

# Create Movie
@app.post('/movies', tags=['Movies'])
def post_movie(movie: Movie):
    movies.append(movie)
    return [movie.model_dump() for movie in movies]